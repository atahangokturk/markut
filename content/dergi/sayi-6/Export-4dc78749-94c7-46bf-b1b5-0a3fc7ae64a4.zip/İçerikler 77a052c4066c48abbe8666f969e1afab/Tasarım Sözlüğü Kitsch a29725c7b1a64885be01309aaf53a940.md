# Tasarım Sözlüğü: Kitsch

Oluşturan: GÖKSU GÖKTÜRK
Oluşturuldu: Feb 5, 2021 1:41 AM
Son Düzenleyen: GÖKSU GÖKTÜRK
Tamamlandı: No