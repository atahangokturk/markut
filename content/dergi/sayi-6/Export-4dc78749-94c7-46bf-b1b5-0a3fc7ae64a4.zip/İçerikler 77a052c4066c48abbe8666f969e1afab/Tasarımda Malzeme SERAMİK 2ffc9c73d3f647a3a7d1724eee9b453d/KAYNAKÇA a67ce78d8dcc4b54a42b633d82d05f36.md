# KAYNAKÇA

[https://www.wikihow.com/Make-Pottery](https://www.wikihow.com/Make-Pottery)

[https://en.wikipedia.org/wiki/Slipcasting](https://en.wikipedia.org/wiki/Slipcasting)

[https://www.planetmugs.com.au/how-are-ceramic-mugs-made](https://www.planetmugs.com.au/how-are-ceramic-mugs-made)

[https://www.sciencedirect.com/topics/engineering/porous-mold](https://www.sciencedirect.com/topics/engineering/porous-mold)

[https://www.lucideon.com/ceramics/what-we-do/process-optimization](https://www.lucideon.com/ceramics/what-we-do/process-optimization)

[https://solutionsinmotion.clevelandvibrator.com/eight-steps-of-ceramics-processing-and-industrial-vibration/](https://solutionsinmotion.clevelandvibrator.com/eight-steps-of-ceramics-processing-and-industrial-vibration/)

[http://www.velimirvukicevic.com/galerie_oeuvres.html](http://www.velimirvukicevic.com/galerie_oeuvres.html)

[https://www.ceramicsnow.org/velimirvukicevic/](https://www.ceramicsnow.org/velimirvukicevic/)

[https://dergipark.org.tr/tr/download/article-file/203760](https://dergipark.org.tr/tr/download/article-file/203760)

[https://www.thecanadianencyclopedia.ca/en/article/greg-payce#:~:text=He draws on history%2C ancient,artist residencies around the world](https://www.thecanadianencyclopedia.ca/en/article/greg-payce#:~:text=He%20draws%20on%20history%2C%20ancient,artist%20residencies%20around%20the%20world)

[https://www.gardinermuseum.on.ca/event/greg-payce-illusions/](https://www.gardinermuseum.on.ca/event/greg-payce-illusions/)

[https://www.gallerieswest.ca/magazine/stories/greg-payce%3A-"illusions'-gardiner-museum%2C-toronto%2C-february-2-to-may-6%2C-2012/](https://www.gallerieswest.ca/magazine/stories/greg-payce%3A-%22illusions%27-gardiner-museum%2C-toronto%2C-february-2-to-may-6%2C-2012/)

[https://www.artoronto.ca/?p=6908](https://www.artoronto.ca/?p=6908)

[https://www.boredpanda.com/optical-illusion-vases-greg-payce/?utm_source=google&utm_medium=organic&utm_campaign=organic](https://www.boredpanda.com/optical-illusion-vases-greg-payce/?utm_source=google&utm_medium=organic&utm_campaign=organic)

[https://www.gardinermuseum.on.ca/event/greg-payce-illusions/](https://www.gardinermuseum.on.ca/event/greg-payce-illusions/)

[https://tr.wikipedia.org/wiki/Füreya_Koral](https://tr.wikipedia.org/wiki/F%C3%BCreya_Koral)

[https://www.ensonhaber.com/biyografi/sanatci/fureya-koral-kimdir](https://www.ensonhaber.com/biyografi/sanatci/fureya-koral-kimdir)

[http://gorunumgazetesi.net/guncel/anafartalarda-tarihi-eserler-esnafa-raf-oldu](http://gorunumgazetesi.net/guncel/anafartalarda-tarihi-eserler-esnafa-raf-oldu)

[http://www.istanbulkadinmuzesi.org/fureyya-koral](http://www.istanbulkadinmuzesi.org/fureyya-koral)

[https://www.iyikigormusum.com/cumhuriyet-doneminin-ilk-kadin-seramik-sanatcisi-fureya-koral](https://www.iyikigormusum.com/cumhuriyet-doneminin-ilk-kadin-seramik-sanatcisi-fureya-koral)

[https://studiopotter.org/plum-tree-pottery](https://studiopotter.org/plum-tree-pottery)

[https://asuartmuseum.asu.edu/sites/default/files/glick_john_biography.pdf](https://asuartmuseum.asu.edu/sites/default/files/glick_john_biography.pdf)

[https://en.wikipedia.org/wiki/John_Glick](https://en.wikipedia.org/wiki/John_Glick)

[https://cranbrookartmuseum.org/product/john-glick/](https://cranbrookartmuseum.org/product/john-glick/)

[https://tr.wikipedia.org/wiki/Sadi_Diren](https://tr.wikipedia.org/wiki/Sadi_Diren)

[https://m.bianet.org/bianet/yasam/194081-bu-dunyadan-bir-sadi-diren-gecti-dunyada-baris-kaldi](https://m.bianet.org/bianet/yasam/194081-bu-dunyadan-bir-sadi-diren-gecti-dunyada-baris-kaldi)

[https://www.arkitera.com/haber/sadi-diren-seramigi-tamamiyla-tesaduf-olarak-sectim/](https://www.arkitera.com/haber/sadi-diren-seramigi-tamamiyla-tesaduf-olarak-sectim/)

[https://tr.wikipedia.org/wiki/Bedri_Rahmi_Eyüboğlu#Duvar_resmi](https://tr.wikipedia.org/wiki/Bedri_Rahmi_Ey%C3%BCbo%C4%9Flu#Duvar_resmi)

[https://www.karar.com/bedri-rahmi-eyuboglunun-tarihi-mozaikleri-kapatilarak-uzerine-1569284](https://www.karar.com/bedri-rahmi-eyuboglunun-tarihi-mozaikleri-kapatilarak-uzerine-1569284)

[https://www.martidergisi.com/sanatci-sair-ve-ogretmen-bir-aydinimiz-bedri-rahmi-eyuboglu/](https://www.martidergisi.com/sanatci-sair-ve-ogretmen-bir-aydinimiz-bedri-rahmi-eyuboglu/)

[https://www.hurriyet.com.tr/yazarlar/gila-benmayor/bedri-rahmi-hem-istanbulun-kedisi-hem-anadolunun-kendisi-41453182](https://www.hurriyet.com.tr/yazarlar/gila-benmayor/bedri-rahmi-hem-istanbulun-kedisi-hem-anadolunun-kendisi-41453182)

[https://lcivelekoglu.blogspot.com/2013/10/tarihten-bugune-dusen-notlar-19-ekim.html](https://lcivelekoglu.blogspot.com/2013/10/tarihten-bugune-dusen-notlar-19-ekim.html)

[https://tr.wikipedia.org/wiki/Jale_Yılmabaşar](https://tr.wikipedia.org/wiki/Jale_Y%C4%B1lmaba%C5%9Far)

[http://in-between.online/tr/things/2017/1/13/m881h8o3d7yg0wjrh20w5z6brrzmfy](http://in-between.online/tr/things/2017/1/13/m881h8o3d7yg0wjrh20w5z6brrzmfy)

[https://www.biyografya.com/biyografi/7618](https://www.biyografya.com/biyografi/7618)

[http://www.jaleyilmabasar.com/biyografi.html](http://www.jaleyilmabasar.com/biyografi.html)

[https://www.carollongpottery.com/](https://www.carollongpottery.com/)

[http://www.vernonfilleyartmuseum.org/carol-long-art-for-sale-fundraiser/](http://www.vernonfilleyartmuseum.org/carol-long-art-for-sale-fundraiser/)

[https://www.wkreda.com/about/wkreda-news/p/item/20062/carol-long-pottery-represents-the-incredible-artistic-talent-found-within-western-kansas](https://www.wkreda.com/about/wkreda-news/p/item/20062/carol-long-pottery-represents-the-incredible-artistic-talent-found-within-western-kansas)

[https://www.luxcenter.org/artist/carol-long](https://www.luxcenter.org/artist/carol-long)

[https://www.carollongpottery.com/bio--resume.html](https://www.carollongpottery.com/bio--resume.html)