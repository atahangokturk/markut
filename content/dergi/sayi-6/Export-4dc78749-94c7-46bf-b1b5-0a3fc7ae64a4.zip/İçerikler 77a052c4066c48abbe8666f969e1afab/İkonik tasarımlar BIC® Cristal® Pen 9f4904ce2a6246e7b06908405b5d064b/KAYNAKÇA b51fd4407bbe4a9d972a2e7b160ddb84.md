# KAYNAKÇA

- [https://blog.ofix.com/ladislao-biro-ve-tukenmez-kalemin-icadi/](https://blog.ofix.com/ladislao-biro-ve-tukenmez-kalemin-icadi/)
- [https://en.wikipedia.org/wiki/Bic_Cristal](https://en.wikipedia.org/wiki/Bic_Cristal)
- [https://www.mosa.com/en/inspiration/notes/spring-2019/bic-cristal](https://www.mosa.com/en/inspiration/notes/spring-2019/bic-cristal)
- [https://designmuseum.org/discover-design/all-design-objects/bic-biro](https://designmuseum.org/discover-design/all-design-objects/bic-biro)
- [https://www.sihirlifasulyeler.com/teknoloji/tukenmez-kalem-nasil-calisi](https://www.sihirlifasulyeler.com/teknoloji/tukenmez-kalem-nasil-calisir)
- [https://www.bicworld.com/en/about-us/who-we-are](https://www.bicworld.com/en/about-us/who-we-are)