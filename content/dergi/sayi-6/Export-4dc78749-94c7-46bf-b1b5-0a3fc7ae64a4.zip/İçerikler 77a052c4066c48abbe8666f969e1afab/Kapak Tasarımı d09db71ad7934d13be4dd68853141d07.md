# Kapak Tasarımı

Oluşturan: Atahan Göktürk Güner
Oluşturuldu: Jan 12, 2021 8:28 PM
Son Düzenleyen: Zeynep Yarar
Tamamlandı: No

[Kapak%20Tasar%C4%B1m%C4%B1%20d09db71ad7934d13be4dd68853141d07/kapak-tasarm.pdf](Kapak%20Tasar%C4%B1m%C4%B1%20d09db71ad7934d13be4dd68853141d07/kapak-tasarm.pdf)